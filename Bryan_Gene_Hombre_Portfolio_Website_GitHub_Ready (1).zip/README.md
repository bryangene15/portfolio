# Bryan Gene C. Hombre - Portfolio Website

This is a GitHub Pages-ready portfolio website.

## Files
- `index.html` - single-file portfolio website with built-in CSS
- `README.md` - publishing instructions

## How to Publish on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`.
3. Go to repository Settings > Pages.
4. Under Build and deployment, choose "Deploy from a branch."
5. Select the `main` branch and `/root` folder.
6. Save and wait for GitHub to publish your site.

## Featured Websites
- https://matrixgroupone.com/
- https://www.twinhomebuyer.com/
- https://peninsulaplumbingsolutions.com/
